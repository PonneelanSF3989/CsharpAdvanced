global using NUnit.Framework;

public class Calculator
{
    public dynamic Addition(dynamic number1, dynamic number2)
    {
        return number1+number2;
    }
}