﻿using System;
namespace Exercise3;
class Program
{
    public static void Main(string[] args)
    {
        
        Operation.MultiDelegate();
        Operation.singleDelegate();
    }
}