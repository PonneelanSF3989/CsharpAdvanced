﻿using System;
namespace Exercise2;
class Program
{
    public static void Main(string[] args)
    {
        
        Operation.CallEvent();
    }
}