﻿using System;
namespace Exercise3;

class program
{
    public static void Main(string[] args)
    {
        Operation.CallEvent();
    }
}