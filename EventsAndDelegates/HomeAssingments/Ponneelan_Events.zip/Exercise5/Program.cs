﻿using System;
using System.IO;
namespace Exercise5;

class program
{
    public static void Main(string[] args)
    {
        Operation.EventHolder();
    }
}