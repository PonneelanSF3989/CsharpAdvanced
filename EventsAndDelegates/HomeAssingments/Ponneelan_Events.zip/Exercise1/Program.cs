﻿using System;
namespace Exercise1;
class Program
{
    public static void Main(string[] args)
    {
        Operation.CallEvent();
    }
}