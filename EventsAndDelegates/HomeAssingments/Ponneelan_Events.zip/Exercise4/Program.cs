﻿using System;
namespace Exercise4;

class Program
{
    public static void Main(string[] args)
    {
        Operation.EventHolder();
    }
}