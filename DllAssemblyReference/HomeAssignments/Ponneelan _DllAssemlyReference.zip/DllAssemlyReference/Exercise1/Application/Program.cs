﻿using System;
using System.Collections.Generic;
namespace Application;

class Program
{
    public static void Main(string[] args)
    {
        Operators.MainMenu();
        
        
        
        
        
        
        
        
        
       
    }
}