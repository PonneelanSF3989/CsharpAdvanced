﻿using System;
using 
namespace Application1;
class Program
{
    public static void Main(string[] args)
    {
        Application1
    }
}